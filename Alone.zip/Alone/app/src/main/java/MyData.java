public class MyData {
}
