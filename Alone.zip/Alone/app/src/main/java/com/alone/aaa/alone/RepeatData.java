package com.alone.aaa.alone;

public class RepeatData {

    public int index;
    public String userID;
    public int info_idx;
    public String comment;
    public String mDate;



    public RepeatData(int index, String userID, int info_idx, String comment, String mDate){
        this.index = index;
        this.userID = userID;
        this.info_idx = info_idx;
        this.comment = comment;
        this.mDate = mDate;



    }

}
