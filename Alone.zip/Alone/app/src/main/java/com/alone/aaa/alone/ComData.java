package com.alone.aaa.alone;

public class ComData {
    public String userid;
    public String name;
    public String addr;
    public String kindsof;
    public String image_url;
    public String ment;

    public ComData(String userid, String name, String addr, String kindsof, String image_url,
                   String ment){
        this.userid = userid;
        this.name = name;
        this.addr = addr;
        this.kindsof = kindsof;
        this.image_url = image_url;
        this.ment = ment;

    }





}
