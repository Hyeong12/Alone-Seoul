package com.alone.aaa.alone;

public class MyData {

    public String ID;
    public String name;
    public String addr;
    public String img;
    public MyData(String ID, String name,String addr, String img){
        this.ID = ID;
        this.name = name;
        this.addr = addr;
        this.img = img;

        }
}
